﻿# Laravel Modular Routes Template

Kerangka Laravel 12 kosong untuk memulai proyek baru. Contoh pemisahan route tersedia di folder `routes`.

`routes/web.php` memuat modul berikut:

- `eco-gui.php`
- `profile.php`
- `eco-katalog.php`
- `eco-klaim.php`
- `auth.php`
- `eco-admin.php`

Beberapa route hanya placeholder. Tambahkan controller, view, validasi, dan autentikasi sesuai kebutuhan proyek.

## Menjalankan

```powershell
composer install
Copy-Item .env.example .env
php artisan key:generate
php artisan migrate
php artisan serve
```

Buka `http://127.0.0.1:8000`. Gunakan PHP 8.2 atau lebih baru. Jika Composer gagal mengunduh paket di Windows, aktifkan ekstensi `zip` pada `php.ini` yang digunakan Composer, atau pasang 7-Zip.
